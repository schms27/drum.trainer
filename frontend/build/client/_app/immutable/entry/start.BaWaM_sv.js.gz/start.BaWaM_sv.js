import{l as o,a as r}from"../chunks/BjUChR8d.js";export{o as load_css,r as start};
